class SumOfTwoNumbers:
    
    def __init__(self,num1,num2) -> None:
        self.num1=num1
        self.num2=num2

        
    def calculatesum(self):
        print(self.num1+self.num2)
    
