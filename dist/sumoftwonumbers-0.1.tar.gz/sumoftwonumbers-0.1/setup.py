from setuptools import setup

setup(
    name='sumoftwonumbers',
    version='0.1',
    description='It will add given two Numbers of Your Choice',
    author='HariSrujan Reddy C',
    packages=['sumoftwonumbers'],
    zip_safe=False
    
)

